# Bai tap co ban
# Cau 1:
puts("nhap vao so nguyen n");
number_123 = gets.to_i()
s_123 = 0
for i_123 in 0..number_123  do
    if (i_123 % 2) !=0
        s_123 = s_123 + i_123
    end
end
puts("Tong cac so nguyen duong 0-n la: ",s_123)
