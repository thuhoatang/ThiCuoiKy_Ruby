require "test_helper"

class CayThuocNamTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
